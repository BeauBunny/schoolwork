package com.Util;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class PowerBankTableUtil extends Box {

    private  JTable table;
    private Vector<String> titles;
    private Vector<Vector> tableDate;
    private TableModel tableModel;

    public PowerBankTableUtil() throws SQLException, ClassNotFoundException {
        super(BoxLayout.Y_AXIS);//组件垂直布局

        JPanel Panel=new JPanel();

        String[] ts={"编号","充电宝类型","充电宝剩余电量","充电宝租借状态","充电宝租借时长"};
        titles=new Vector<>();
        for (String title : ts) {
            titles.add(title);
        }

        tableDate=new Vector<>();


        tableModel=new DefaultTableModel(tableDate,titles);
        table=new JTable(tableModel){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }//设置不能编辑
        };
        //设置只能选中一行
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        RequestDate();
        JScrollPane scrollPane=new JScrollPane(table);
        this.add(scrollPane);
    }
    public void RequestDate() throws SQLException, ClassNotFoundException {
        Connection con=DBHelper.getConn();
        String sql="select * from t_powerbanktype";
        PreparedStatement pstmt=con.prepareStatement(sql);
        ResultSet rs=pstmt.executeQuery();
        while (rs.next()){
            Vector vector=new Vector();
            vector.add(rs.getInt("id"));
            vector.add(rs.getString("powerBankType"));
            vector.add(rs.getString("remainingpower"));
            vector.add(rs.getString("rentstatus"));
            vector.add(rs.getString("renttime"));

            tableDate.add(vector);
        }

    }
    
}
