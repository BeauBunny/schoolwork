package com.Util;

import com.model.PowerBankType;
import com.model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ListingUtil {
    public static  int add(PowerBankType powerBankType) throws ClassNotFoundException, SQLException {
        Connection conn = DBHelper.getConn();
        String sql="insert  into t_powerbanktype(id,powerbanktype,remainingpower,rentstatus,renttime) values (null,?,?,?,?)";
        PreparedStatement pstmt= conn.prepareStatement(sql);
        pstmt.setString(1,powerBankType.getPowerBankType());
        pstmt.setFloat(2,powerBankType.getRemainingpower());
        pstmt.setString(3,powerBankType.getRentstatus());
        pstmt.setString(4,powerBankType.getRenttime());
        int rs=pstmt.executeUpdate();
        return rs;
    }
}
