package com.Util;

import com.model.PowerBankType;
import com.model.User;
import com.view.Recharge;
import com.view.TimeGUI;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PowerBankChargerCalculationUtil {
    public static void commonPowerBank(PowerBankType p,User user) throws ClassNotFoundException, SQLException {
        Connection conn = DBHelper.getConn();
        String sql = "select *from t_powerbanktype where powerbanktype=?  and remainingpower > ? and rentstatus = ?";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, p.getPowerBankType());
        pstmt.setFloat(2,50.f);
        pstmt.setString(3, "未被租借");
        ResultSet rs = pstmt.executeQuery();
        if (rs != null) {
            if (rs.next()) {
                int id = rs.getInt("id");
                String sql1 = "update t_powerbanktype set rentstatus=? where id=?";
                PreparedStatement pstmt1 = conn.prepareStatement(sql1);
                pstmt1.setString(1, "已被租借");
                pstmt1.setInt(2, id);
                int rs2 = pstmt1.executeUpdate();
                JOptionPane.showMessageDialog(null, "租借成功");
                TimeGUI timeGUI=new TimeGUI(user,p.getPowerBankType());
            } else {
                JOptionPane.showMessageDialog(null, "没有此类型可租借的充电宝");
            }
        } else {
            JOptionPane.showMessageDialog(null, "没有此类型可租借的充电宝");
        }
    }
}
