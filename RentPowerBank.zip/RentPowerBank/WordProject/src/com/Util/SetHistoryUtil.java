package com.Util;

import com.model.History;
import com.model.PowerBankType;
import com.model.TimeDate;
import com.model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SetHistoryUtil {
    public static void addHistory(String s, User user, String p) throws ClassNotFoundException, SQLException {
        Connection conn = DBHelper.getConn();
        String sql="insert into t_history  (username,userpowerbank,renttime,rentstart,rentfinish) values (?,?,?,?,?)";
        PreparedStatement pstmt=conn.prepareStatement(sql);
//        pstmt.setInt(1,h.getId());
        pstmt.setString(1,user.getUsername());
        pstmt.setString(2,p);
        pstmt.setString(3,s);
        pstmt.setString(4,TimeDate.starttime);
        pstmt.setString(5, TimeDate.finishtime);
        int rs=pstmt.executeUpdate();
    }
}
