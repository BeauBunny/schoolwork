package com.Util;

import com.model.PowerBankType;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ManageUpdate {
    public static void Change(PowerBankType p) throws ClassNotFoundException, SQLException {
        Connection conn = DBHelper.getConn();
        String sql="update t_powerbanktype set powerbanktype=?,remainingpower=?,rentstatus=?,renttime=?  where  id=?";

        PreparedStatement pstmt=conn.prepareStatement(sql);
        pstmt.setString(1,p.getPowerBankType());
        pstmt.setFloat(2,p.getRemainingpower());
        pstmt.setString(3,p.getRentstatus());
        pstmt.setString(4,p.getRenttime());
        pstmt.setInt(5,p.getId());
        int rs=pstmt.executeUpdate();
    }
}
