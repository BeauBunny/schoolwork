package com.Util;

import com.model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UserDeleteUtil {
    public static void UserDelete(String user) throws ClassNotFoundException, SQLException {
        Connection conn = DBHelper.getConn();
        String sql="delete from t_user where username=?";
        PreparedStatement pstmt=conn.prepareStatement(sql);
        pstmt.setString(1,user);
        int rs=pstmt.executeUpdate();
    }
}
