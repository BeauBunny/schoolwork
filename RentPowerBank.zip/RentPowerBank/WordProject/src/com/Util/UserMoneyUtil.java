package com.Util;

import com.model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserMoneyUtil {
    public static Double usermoney;
    public static Double getUserMoney(String user) throws ClassNotFoundException, SQLException {
        Connection conn = DBHelper.getConn();
        String sql="select money from t_user where username=?";
        PreparedStatement pstmt=conn.prepareStatement(sql);
        pstmt.setString(1, user);
        ResultSet rs=pstmt.executeQuery();
        rs.next();
         usermoney = rs.getDouble("money");
        return usermoney;

    }
    public static void consumelaterMoney(Double m,String user) throws ClassNotFoundException, SQLException {
        Connection conn = DBHelper.getConn();
        String sql1="update t_user set money=? where username=?";
        PreparedStatement pstmt1=conn.prepareStatement(sql1);
        pstmt1.setDouble(1,m);
        pstmt1.setString(2,user);
        int rs1=pstmt1.executeUpdate();
    }
}
