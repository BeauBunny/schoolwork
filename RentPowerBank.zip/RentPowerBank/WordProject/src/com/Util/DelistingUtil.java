package com.Util;

import com.model.PowerBankType;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DelistingUtil {
    public static void DelistingPowerBank(PowerBankType p) throws ClassNotFoundException, SQLException {
        Connection conn = DBHelper.getConn();
        String sql="delete from t_powerbanktype where powerbanktype=?";
        PreparedStatement pstmt=conn.prepareStatement(sql);
        pstmt.setString(1,p.getPowerBankType());
        pstmt.executeUpdate();
    }
}
