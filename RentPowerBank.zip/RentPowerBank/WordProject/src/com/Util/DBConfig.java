package com.Util;

public interface DBConfig {
    String url="jdbc:mysql://localhost:3306/user?useUnicode=true&characterEncoding=utf-8";

    String dbUserName="root";

    String dvPassword="12345";

    String jdbcName="com.mysql.jdbc.Driver";
}

