package com.Util;

import java.sql.*;

public class DBHelper implements DBConfig{
    private static Connection conn;
    private static Statement statement;
    private  static ResultSet rs;

    public DBHelper() {
    }

    /**
     * 数据库连接
     * @return
     * @throws ClassNotFoundException
     */
    public static Connection getConn() throws ClassNotFoundException {
        Class.forName(jdbcName);
        try {
            conn= DriverManager.getConnection(url,dbUserName,dvPassword);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return conn;
    }

    /**
     * 关闭数据库连接
     */
    public  static  void close(Connection conn){
//        if (stmt!=null){
//            try {
//                stmt.close();
//            } catch (SQLException e) {
//                e.getStackTrace();
//            }
//        }
        if (conn!=null){
            try {
                conn.close();
            } catch (SQLException e) {
                e.getStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        DBHelper dbHelper=new DBHelper();
        try {
            dbHelper.getConn();
            System.out.println("数据库连接成功");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("数据库连接失败");
        }
    }


}


