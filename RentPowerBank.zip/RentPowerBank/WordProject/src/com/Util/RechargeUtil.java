package com.Util;

import com.model.User;
import com.view.Recharge;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RechargeUtil {
    public static  void Recharge(String username,Double number) throws ClassNotFoundException, SQLException {
        Connection conn = DBHelper.getConn();


        Double money=0.0;
        String sql="update t_user set money=? where username=?";
        String sql2="select money from  t_user where username=?";
        PreparedStatement pstmt=conn.prepareStatement(sql2);
        pstmt.setString(1,username);
        ResultSet rs = pstmt.executeQuery();
        while (rs.next()){
            money=rs.getDouble(1);
        }
        money+= number;
        PreparedStatement pstmt1=conn.prepareStatement(sql);
        pstmt1.setDouble(1,money);
        pstmt1.setString(2,username);
        int rs1=pstmt1.executeUpdate();
    }


}
