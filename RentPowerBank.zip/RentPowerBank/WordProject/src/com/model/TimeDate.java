package com.model;

public class TimeDate {
   public  static String starttime;

    public static String finishtime;
    public static int seconds;
    public static int minutes;
    public static int hours;

    public static void setSeconds(int seconds) {
        TimeDate.seconds = seconds;
    }

    public static void setMinutes(int minutes) {
        TimeDate.minutes = minutes;
    }

    public static void setHours(int hours) {
        TimeDate.hours = hours;
    }

    public static void setStarttime(String starttime) {
        TimeDate.starttime = starttime;
    }

    public static void setFinishtime(String finishtime) {
        TimeDate.finishtime = finishtime;
    }
}
