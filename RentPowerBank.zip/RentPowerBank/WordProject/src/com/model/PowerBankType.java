package com.model;

public class PowerBankType {
    private int id;
    public static String powerBankType;
    private float remainingpower;
    private String renttime;
    private String rentstatus;

    public PowerBankType(int id, String powerBankType) {
        this.id = id;
        this.powerBankType = powerBankType;
    }


    public PowerBankType(String powerBankType, float remainingpower, String renttime, String rentstatus) {
        this.powerBankType = powerBankType;
        this.remainingpower = remainingpower;
        this.renttime = renttime;
        this.rentstatus = rentstatus;
    }

    public PowerBankType(int id, String powerBankType, float remainingpower, String rentstatus, String renttime) {
        this.id = id;
        this.powerBankType = powerBankType;
        this.remainingpower = remainingpower;
        this.renttime = renttime;
        this.rentstatus = rentstatus;
    }

    public PowerBankType() {
    }

    public PowerBankType(String powerBankType) {
        this.powerBankType = powerBankType;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public static String getPowerBankType() {
        return powerBankType;
    }

    public float getRemainingpower() {
        return remainingpower;
    }

    public void setRemainingpower(float remainingpower) {
        this.remainingpower = remainingpower;
    }

    public String getRenttime() {
        return renttime;
    }

    public void setRenttime(String renttime) {
        this.renttime = renttime;
    }

    public String getRentstatus() {
        return rentstatus;
    }

    public void setRentstatus(String rentstatus) {
        this.rentstatus = rentstatus;
    }

    public static  void setPowerBankType(String powerBankType) {
        PowerBankType.powerBankType = powerBankType;
    }
}

