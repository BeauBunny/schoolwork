package com.model;

public class History {
    private String username;
    private int id;
    private String renttime;
    private String rentstart;
    private String rentfinish;

    public History(String username, int id, String renttime, String rentstart, String rentfinish) {
        this.username = username;
        this.id = id;
        this.renttime = renttime;
        this.rentstart = rentstart;
        this.rentfinish = rentfinish;
    }

    public String getRentstart() {
        return rentstart;
    }

    public void setRentstart(String rentstart) {
        this.rentstart = rentstart;
    }

    public String getRentfinish() {
        return rentfinish;
    }

    public void setRentfinish(String rentfinish) {
        this.rentfinish = rentfinish;
    }


    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRenttime() {
        return renttime;
    }

    public void setRenttime(String renttime) {
        this.renttime = renttime;
    }
}
