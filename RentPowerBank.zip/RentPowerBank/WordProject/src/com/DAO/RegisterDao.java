package com.DAO;

import com.Util.DBHelper;
import com.model.User;
import com.view.RegisterFrm;

import java.sql.*;

public class RegisterDao {
    public static boolean register(Connection con, User user) throws SQLException {
        boolean result=false;
        String sql="insert into t_user (id,username,password) values (?,?,?)";
        PreparedStatement pstmt=con.prepareStatement(sql);
        pstmt.setInt(1, user.getId());
        pstmt.setString(2, user.getUsername());
        pstmt.setString(3, user.getPassword());
//        pstmt.setString(4, user.getGender());
        result=pstmt.executeUpdate()>0?true:false;
        DBHelper.close(con);
        return result;
    }
}
