package com.DAO;

import com.Util.DBHelper;
import com.model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * 用户Dao类
 */
public class UserDao {
    /**
     * 登陆验证
     * @param conn
     * @param user
     * @return
     * @throws SQLException
     */
    public static User login(Connection conn, User user) throws SQLException {
        User resultUser=null;
        String sql="select *from t_user where username=? and password=?";
        PreparedStatement pstmt=conn.prepareStatement(sql);
        pstmt.setString(1,user.getUsername());
        pstmt.setString(2, user.getPassword());
        ResultSet rs=pstmt.executeQuery();
        if (rs.next()){
            resultUser=new User();
            resultUser.setId(rs.getInt("id"));
            resultUser.setUsername(rs.getString("username"));
            resultUser.setPassword(rs.getString("password"));

        }
        DBHelper.close(conn);

        return resultUser;
    }

}
