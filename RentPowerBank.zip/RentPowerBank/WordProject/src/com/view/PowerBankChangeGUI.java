package com.view;

import com.Util.DBHelper;
import com.Util.ManageUpdate;
import com.Util.PowerBankTableUtil;
import com.model.PowerBankType;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class PowerBankChangeGUI extends Box {
    private  JTable table;
    private Vector<String> titles;
    private Vector<Vector> tableDate;
    private TableModel tableModel;

    public PowerBankChangeGUI() throws IOException, SQLException, ClassNotFoundException {
        super(BoxLayout.Y_AXIS);

        JPanel jPanel=new JPanel();

        Box vBox=createVerticalBox();

        Box searchBox=Box.createHorizontalBox();
        JLabel powerBanktype=new JLabel("充电宝类型:");
        JTextField txt_powerBanktype=new JTextField(10);
        JButton searchbtn=new JButton("查询");
        searchBox.add(powerBanktype);
        searchBox.add(Box.createHorizontalStrut(5));
        searchBox.add(txt_powerBanktype);
        searchBox.add(Box.createHorizontalStrut(10));
        searchBox.add(searchbtn);

//        PowerBankTableUtil p=new PowerBankTableUtil();
        Box box4=Box.createHorizontalBox();

        Box box0=Box.createHorizontalBox();
        JLabel id=new JLabel("编号:");
        JTextField txt_id=new JTextField(10);
        box0.add(Box.createHorizontalStrut(10));
        box0.add(id);
        box0.add(Box.createHorizontalStrut(5));
        box0.add(txt_id);
        box0.add(Box.createHorizontalStrut(600));

        Box box1=Box.createHorizontalBox();
        JLabel powerBanktype1=new JLabel("充电宝类型:");
        JTextField txt_powerBanktype1=new JTextField(10);
        JLabel remainingpower=new JLabel("充电宝剩余电量:");
        JTextField txt_remainingpower=new JTextField(10);
        box1.add(Box.createHorizontalStrut(10));
        box1.add(powerBanktype1);
        box1.add(Box.createHorizontalStrut(5));
        box1.add(txt_powerBanktype1);
        box1.add(Box.createHorizontalStrut(10));
        box1.add(remainingpower);
        box1.add(Box.createHorizontalStrut(5));
        box1.add(txt_remainingpower);
        box1.add(Box.createHorizontalStrut(20));

        Box box2=Box.createHorizontalBox();
        JLabel rentstaus=new JLabel("充电宝租借状态:");
        JTextField txt_rentstaus=new JTextField(10);
        JLabel renttime=new JLabel("充电宝租借时间:");
        JTextField txt_renttime=new JTextField(10);
        box2.add(Box.createHorizontalStrut(10));
        box2.add(rentstaus);
        box2.add(Box.createHorizontalStrut(5));
        box2.add(txt_rentstaus);
        box2.add(Box.createHorizontalStrut(10));
        box2.add(renttime);
        box2.add(Box.createHorizontalStrut(5));
        box2.add(txt_renttime);
        box2.add(Box.createHorizontalStrut(20));

        Box box3=Box.createHorizontalBox();
        JButton changebtn=new JButton("修改");
        box3.add(changebtn);




        String[] ts={"编号","充电宝类型","充电宝剩余电量","充电宝租借状态","充电宝租借时长"};
        titles=new Vector<>();
        for (String title : ts) {
            titles.add(title);
        }
        

        tableDate=new Vector<>();


        tableModel=new DefaultTableModel(tableDate,titles);
        table=new JTable(tableModel);
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {//表格点击事件处理
                int row = table.getSelectedRow();
                txt_id.setText((Integer) table.getValueAt(row,0)+"");
                txt_powerBanktype1.setText((String) table.getValueAt(row,1)+"");
                txt_remainingpower.setText((String) table.getValueAt(row,2)+"");
                txt_rentstaus.setText((String)table.getValueAt(row,3)+"");
                txt_renttime.setText((String)table.getValueAt(row,4)+"");

            }
        });

        changebtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String s0=txt_id.getText().trim();
                int s00=Integer.parseInt(s0);
                String s1=txt_powerBanktype1.getText().trim();
                String s2=txt_remainingpower.getText().trim();
                Float s22=Float.parseFloat(s2);
                String s3=txt_rentstaus.getText().trim();
                String s4=txt_renttime.getText().trim();

                PowerBankType p=new PowerBankType(s00,s1,s22,s3,s4);
                try {
                    ManageUpdate.Change(p);
                    JOptionPane.showMessageDialog(null,"修改成功!");
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        });
//        {
//            @Override
//            public boolean isCellEditable(int row, int column) {
//                return false;
//            }//设置不能编辑
//        };
        //设置只能选中一行
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        RequestDate();
        JScrollPane scrollPane=new JScrollPane(table);
        box4.add(scrollPane);

        vBox.add(Box.createVerticalStrut(10));
        vBox.add(searchBox);
        vBox.add(Box.createVerticalStrut(20));
//        vBox.add(p);
        vBox.add(box4);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(box0);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(box1);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(box2);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(box3);


        add(vBox);
    }
    public void RequestDate() throws SQLException, ClassNotFoundException {
        Connection con = DBHelper.getConn();
        String sql = "select * from t_powerbanktype";
        PreparedStatement pstmt = con.prepareStatement(sql);
        ResultSet rs = pstmt.executeQuery();
        while (rs.next()) {
            Vector vector = new Vector();
            vector.add(rs.getInt("id"));
            vector.add(rs.getString("powerBankType"));
            vector.add(rs.getString("remainingpower"));
            vector.add(rs.getString("rentstatus"));
            vector.add(rs.getString("renttime"));

            tableDate.add(vector);
        }
    }
}
