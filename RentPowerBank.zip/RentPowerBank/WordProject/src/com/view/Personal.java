package com.view;

import com.DAO.UserDao;
import com.Util.DBHelper;
import com.Util.UserMoneyUtil;
import com.model.User;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;

public class Personal extends Box {
    public  static Double userMoney;
    public  static String username;
    public Personal(User user) throws SQLException, ClassNotFoundException {
//        setSize(300,200);
//        setTitle("个人资料");
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(EXIT_ON_CLOSE);
        super(BoxLayout.Y_AXIS);

        JPanel jPanel=new JPanel();

        Box vBox=Box.createVerticalBox();

        Box nameBox=Box.createHorizontalBox();
        JLabel name=new JLabel("用户名:");
        JLabel txtname=new JLabel(user.getUsername());
//        JLabel txtname=new JLabel("");
        nameBox.add(name);
        nameBox.add(Box.createHorizontalStrut(5));
        nameBox.add(txtname);

        Box packetBox=Box.createHorizontalBox();
        JLabel packet=new JLabel("我的钱包:");
        userMoney = UserMoneyUtil.getUserMoney(user.getUsername());
        username= user.getUsername();
        JLabel money=new JLabel(String.valueOf(userMoney));
//        JLabel money=new JLabel(String.valueOf(""));
        packetBox.add(packet);
        packetBox.add(Box.createHorizontalStrut(5));
        packetBox.add(money);

        Box btnBox=Box.createHorizontalBox();
        JButton xiugai=new JButton("修改");
        JButton back=new JButton("返回");
        btnBox.add(xiugai);
        btnBox.add(Box.createHorizontalStrut(5));
        btnBox.add(back);

        vBox.add(nameBox);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(packetBox);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(btnBox);

//        back.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent actionEvent) {
//                dispose();
//            }
//        });
        add(vBox);

//        add(jPanel);


        setVisible(true);

    }



}
