package com.view;

import com.Util.RechargeUtil;
import com.model.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class Recharge extends JFrame {
    public Recharge(){
        setSize(300,250);
        setTitle("充值界面");
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        this.setLayout(new GridLayout(4,1));

        JPanel jPanel=new JPanel();

        JPanel jPanel3=new JPanel();
        JLabel jLabel3=new JLabel("你的用户名称:");
        JTextField jTextField=new JTextField(10);
        jPanel3.add(jLabel3);
        jPanel3.add(jTextField);

        JPanel jPanel1=new JPanel();
        JLabel jLabel1=new JLabel("请输入充值金额:");
        JTextField jTextField1=new JTextField(10);
        jPanel1.add(jLabel1);
        jPanel1.add(jTextField1);

        JPanel jPanel2=new JPanel();
        JButton recharge=new JButton("充值");
        JButton jButton1=new JButton("返回");
        jPanel2.add(recharge);
        jPanel2.add(jButton1);


        this.add(jPanel);
        this.add(jPanel3);
        this.add(jPanel1);
        this.add(jPanel2);

        jButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                dispose();
            }
        });

        recharge.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
//                User user=new User();
                String username=jTextField.getText().trim();
                String money=jTextField1.getText().trim();
                double number=Double.parseDouble(money);
                try {
                    RechargeUtil.Recharge(username,number);
                    JOptionPane.showMessageDialog(null,"充值成功!");
                    jTextField1.setText("");
                } catch (ClassNotFoundException ex) {
                    ex.getStackTrace();
                } catch (SQLException ex) {
                    ex.getStackTrace();
                }
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        Recharge recharge=new Recharge();
    }
}
