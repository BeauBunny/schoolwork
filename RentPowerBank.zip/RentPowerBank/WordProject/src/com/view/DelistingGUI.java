package com.view;

import com.Util.DelistingUtil;
import com.Util.ListingUtil;
import com.model.PowerBankType;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class DelistingGUI extends Box{
    PowerBankType p=new PowerBankType();
    public DelistingGUI(){
        super(BoxLayout.Y_AXIS);
        Font font = new Font("宋体", Font.PLAIN, 18);
        UIManager.put("Button.font", font);
        UIManager.put("Label.font", font);
        UIManager.put("TextField.font", font);
        UIManager.put("ComboBox.font", font);
        UIManager.put("CheckBox.font", font);
        UIManager.put("RadioButton.font", font);

        JPanel jPanel=new JPanel();

        Box vBox=Box.createVerticalBox();

        Box typeBox=Box.createHorizontalBox();
        JLabel type=new JLabel("充电宝   类型:");
        JTextField texttype=new JTextField(14);
        typeBox.add(Box.createHorizontalStrut(30));
        typeBox.add(type);
        typeBox.add(Box.createHorizontalStrut(6));
        typeBox.add(texttype);
        typeBox.add(Box.createHorizontalStrut(100));


//        Box Box2=Box.createHorizontalBox();
//        JLabel remainingpower=new JLabel("充电宝剩余电量:");
//        JTextField textField2=new JTextField(14);
//        Box2.add(Box.createHorizontalStrut(30));
//        Box2.add(remainingpower);
//        Box2.add(Box.createHorizontalStrut(6));
//        Box2.add(textField2);
//        Box2.add(Box.createHorizontalStrut(100));

//        Box Box3=Box.createHorizontalBox();
//        JLabel rentstatus=new JLabel("充电宝租借状态:");
//        JTextField textField3=new JTextField(14);
//        Box3.add(Box.createHorizontalStrut(30));
//        Box3.add(rentstatus);
//        Box3.add(Box.createHorizontalStrut(6));
//        Box3.add(textField3);
//        Box3.add(Box.createHorizontalStrut(100));

//        Box Box4=Box.createHorizontalBox();
//        JLabel renttime=new JLabel("充电宝租借时长:");
//        JTextField textField4=new JTextField(14);
//        Box4.add(Box.createHorizontalStrut(30));
//        Box4.add(renttime);
//        Box4.add(Box.createHorizontalStrut(6));
//        Box4.add(textField4);
//        Box4.add(Box.createHorizontalStrut(100));

        Box Box5=Box.createHorizontalBox();
        JButton delisting=new JButton("下    架");
        Box5.add(delisting);

        delisting.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String s1=texttype.getText().trim();
//                String s2=textField2.getText().trim();
//                String s3=textField3.getText().trim();
//                String s4=textField4.getText().trim();
//                Float f=Float.parseFloat(s2);


                try {
                    DelistingUtil.DelistingPowerBank(new PowerBankType(s1));
                    JOptionPane.showMessageDialog(null,"下架成功!");
                    texttype.setText("");
                } catch (ClassNotFoundException ex) {
                    throw new RuntimeException(ex);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }

            }
        });

        vBox.add(Box.createVerticalStrut(30));
        vBox.add(typeBox);
        vBox.add(Box.createVerticalStrut(30));
//        vBox.add(Box2);
//        vBox.add(Box.createVerticalStrut(30));
//        vBox.add(Box3);
//        vBox.add(Box.createVerticalStrut(30));
//        vBox.add(Box4);
        vBox.add(Box.createVerticalStrut(30));
        vBox.add(Box5);
        vBox.add(Box.createVerticalStrut(30));

        add(vBox);


    }
}
