package com.view;

import com.Util.DBHelper;
import com.model.History;
import com.model.PowerBankType;
import com.model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class HistoryGUI extends Box {
    private  JTable table;
    private Vector<String> titles;
    private Vector<Vector> tableDate;
    private TableModel tableModel;
    public HistoryGUI(User username) throws SQLException, ClassNotFoundException {
        super(BoxLayout.Y_AXIS);//组件垂直布局

        JPanel Panel=new JPanel();

        String[] ts={"编号","用户名","租借充电宝类型","租借时长","租借开始时间","租借结束时间"};
        titles=new Vector<>();
        for (String title : ts) {
            titles.add(title);
        }

        tableDate=new Vector<>();


        tableModel=new DefaultTableModel(tableDate,titles);
        table=new JTable(tableModel){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }//设置不能编辑
        };
        //设置只能选中一行
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        RequestDate(username);
        JScrollPane scrollPane=new JScrollPane(table);
        this.add(scrollPane);
    }
    public void RequestDate(User user) throws SQLException, ClassNotFoundException {
        Connection con= DBHelper.getConn();
        String sql="select * from t_history where username=?";
        PreparedStatement pstmt=con.prepareStatement(sql);
        pstmt.setString(1,user.getUsername());
        ResultSet rs=pstmt.executeQuery();
        while (rs.next()){
            Vector vector=new Vector();
            vector.add(rs.getInt("id"));
            vector.add(rs.getString("username"));
            vector.add(rs.getString("userpowerbank"));
            vector.add(rs.getString("renttime"));
            vector.add(rs.getString("rentstart"));
            vector.add(rs.getString("rentfinish"));

            tableDate.add(vector);
        }

    }


}
