package com.view;

import com.DAO.UserDao;
import com.Util.DBHelper;
import com.Util.StringUtil;
import com.component.BackgroundPanel;
import com.model.User;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

public class GUI extends JFrame {

    private JLabel username;
    private JLabel password;
    private JTextField text_username;
    private JPasswordField text_password;
    private JButton login;
    private JButton register;
    private JRadioButton user1;
    private JRadioButton admin;

    private DBHelper dbHelper=new DBHelper();

    private UserDao userDao=new UserDao();


    GUI() throws IOException {
        setSize(500,300);
        setTitle("登录界面");
        setLocationRelativeTo(null);
//        setAlwaysOnTop(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);

        BackgroundPanel bgPanel=new BackgroundPanel(ImageIO.read(new File("C:\\Users\\machenlke\\IdeaProjects\\WordProject\\image\\Background.jpg")));

        Box vBox = Box.createVerticalBox();

        Box uBox = Box.createHorizontalBox();
        username=new JLabel("用户名:");
        text_username=new JTextField(16);

        uBox.add(username);
        uBox.add(Box.createHorizontalStrut(20));
        uBox.add(text_username);

        Box pBox=Box.createHorizontalBox();
        password=new JLabel("密    码:");
        text_password=new JPasswordField(16);

        pBox.add(password);
        pBox.add(Box.createHorizontalStrut(20));
        pBox.add(text_password);

        Box bgBox=Box.createHorizontalBox();
        ButtonGroup group = new ButtonGroup();
        user1=new JRadioButton("用户");
        admin=new JRadioButton("管理员");
        group.add(user1);
        group.add(admin);
        user1.setOpaque(false);
        admin.setOpaque(false);
        user1.setSelected(true);

        bgBox.add(user1);
        bgBox.add(admin);


        Box btBox=Box.createHorizontalBox();
        login=new JButton("登录");
        register=new JButton("注册");

        login.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                //获取用户输入的数据
//                Object obj=actionEvent.getSource();
//                String username=text_username.getText();
//                String password=new String(text_password.getPassword());

                //访问登录窗口
//                if (obj == username) {
//                    text_username.grabFocus();
//
//                } else if (obj == text_username) {
//                    login.doClick();
//
//                } else if (username.equals("")) {
//                    JOptionPane.showMessageDialog(null,"请输入用户名");
//                    text_username.requestFocus();
//
//                } else if (password.equals("")) {
//                    JOptionPane.showMessageDialog(null,"请输入密码");
//                    text_password.requestFocus();
//
//                }else  if(username.equals("username") && password.equals("123456")){
//                    JOptionPane.showMessageDialog(null,"登陆成功");
//                    dispose();
//
//                }else {
//                    JOptionPane.showMessageDialog(null,"用户名或密码错误");
//                    text_username.setText("");
//                    text_password.setText("");
//                    text_username.requestFocus();
//                }
                loginActionPerformed(e);
            }
        });


        register.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

                try {
                    RegisterFrm  r=new RegisterFrm();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });


        btBox.add(login);
        btBox.add(Box.createHorizontalStrut(100));
        btBox.add(register);

        vBox.add(Box.createVerticalStrut(10));
        vBox.add(bgBox);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(uBox);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(pBox);
        vBox.add(Box.createVerticalStrut(30));
        vBox.add(btBox);


        bgPanel.add(vBox);
        this.add(bgPanel);
        setVisible(true);





    }

    public JLabel getUsername() {
        return username;
    }

    public void setUsername(JLabel username) {
        this.username = username;
    }

    public JLabel getPassword() {
        return password;
    }

    public void setPassword(JLabel password) {
        this.password = password;
    }

    public JTextField getText_username() {
        return text_username;
    }

    public void setText_username(JTextField text_username) {
        this.text_username = text_username;
    }

    public JPasswordField getText_password() {
        return text_password;
    }

    public void setText_password(JPasswordField text_password) {
        this.text_password = text_password;
    }

    public JButton getLogin() {
        return login;
    }

    public void setLogin(JButton login) {
        this.login = login;
    }

    public JButton getRegister() {
        return register;
    }

    public void setRegister(JButton register) {
        this.register = register;
    }

    /**
     * 登录事件处理
     * @param e
     */
    public void loginActionPerformed(ActionEvent e){
        String username=text_username.getText();
        String password=new String(text_password.getPassword());
//        String user1=user.getText();
//        String admin1=admin.getText();

        Object obj=e.getSource();


        if (StringUtil.isEmpty(username)){
            JOptionPane.showMessageDialog(null,"用户名不能为空");
            return;
        }

        if (StringUtil.isEmpty(password)){
            JOptionPane.showMessageDialog(null,"密码不能为空");
            return;
        }

        User user=new User(username,password);
        Connection conn=null;
        try {
            conn=DBHelper.getConn();
            User currentUser=UserDao.login(conn,user);
            if (currentUser!=null && user1.isSelected()){
                JOptionPane.showMessageDialog(null,"登陆成功");
                PowerBankManage powerBankManage=new PowerBankManage(currentUser);
                dispose();
            } else if (currentUser!=null && admin.isSelected()) {
                JOptionPane.showMessageDialog(null,"登陆成功");
                ManagePowerBank managePowerBank=new ManagePowerBank(currentUser);
                dispose();
            }else {
                JOptionPane.showMessageDialog(null,"用户名或密码错误");
            }
        } catch (ClassNotFoundException | SQLException ex) {
            throw new RuntimeException(ex);
        }

    }
}

