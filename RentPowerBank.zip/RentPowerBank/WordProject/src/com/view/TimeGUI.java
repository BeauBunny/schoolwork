package com.view;

import com.Util.SetHistoryUtil;
import com.model.History;
import com.model.PowerBankType;
import com.model.TimeDate;
import com.model.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TimeGUI extends JFrame {

    public  int seconds=0;
    public int minutes=0;
    public int hours=0;


    public TimeGUI(User user, String p){
        setSize(300,300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("租借时长计时器");

        JPanel jPanel=new JPanel();

        Box vBox=Box.createVerticalBox();

        Box box1=Box.createHorizontalBox();
        JLabel jLabel1=new JLabel("租借时长:");
        jLabel1.setFont(jLabel1.getFont().deriveFont(30.0f));
        box1.add(jLabel1);

        Box box2=Box.createHorizontalBox();
        JLabel label2=new JLabel("00:00:00",SwingConstants.CENTER);
        label2.setFont(label2.getFont().deriveFont(64.0f));
        box2.add(label2);

        Box box3=Box.createHorizontalBox();
        JButton btn=new JButton("归还");
        box3.add(btn);

        Timer timer=new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                seconds++;
                if (seconds>=60){
                    minutes++;
                    seconds=0;
                }
                if (minutes>=60){
                    hours++;
                    minutes=0;
                }
                label2.setText(String.format("%02d:%02d:%02d",hours,minutes,seconds));
            }
        });
        timer.start();

        btn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                Date date=new Date();
                SimpleDateFormat dateFormat=new SimpleDateFormat("yyy-MM-dd HH:mm:ss");
                String time=dateFormat.format(date);
                TimeDate.setFinishtime(time);

                JOptionPane.showMessageDialog(null,label2.getText());
                String label22=label2.getText();
                try {
                    SetHistoryUtil.addHistory(label22,user,p);
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }

                TimeDate.setSeconds(seconds);
                TimeDate.setSeconds(minutes);
                TimeDate.setSeconds(hours);





                dispose();
            }
        });

        vBox.add(box1);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(box2);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(box3);

        jPanel.add(vBox);
        this.add(jPanel);

        setVisible(true);

    }



}
