package com.view;

import com.Util.PowerBankTableUtil;
import com.model.PowerBankType;
import com.model.User;

import javax.swing.*;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class PowerBankManage extends JFrame {


    PowerBankManage(User currentUser){
        setSize(1000,600);
        setLocationRelativeTo(null);
        setTitle("充电包租借界面");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JMenuBar jmb=new JMenuBar();

        JMenu setting=new JMenu("设置");
        JMenuItem aboutme=new JMenuItem("个人");
        JMenuItem exit=new JMenuItem("退出程序");
        setting.add(exit);
        setting.add(aboutme);
        jmb.add(setting);
        setJMenuBar(jmb);
        aboutme.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                try {
                    Personal personal=new Personal(currentUser);
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }
//                dispose();
            }
        });
        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                System.exit(0);//退出
            }
        });

        JSplitPane jSplitPane=new JSplitPane();
        jSplitPane.setContinuousLayout(true);//支持持续布局，即可以拉伸分界线
        jSplitPane.setDividerLocation(150);//分界线从左往右距离
        jSplitPane.setDividerSize(7);//分界线的宽度

        add(jSplitPane);
        DefaultMutableTreeNode root=new DefaultMutableTreeNode("充电宝");
        DefaultMutableTreeNode personcenter=new DefaultMutableTreeNode("个人中心");
        DefaultMutableTreeNode powerBankType=new DefaultMutableTreeNode("充电宝管理");
        DefaultMutableTreeNode powerBankRent=new DefaultMutableTreeNode("充电宝租借");
        DefaultMutableTreeNode powerBankHistory=new DefaultMutableTreeNode("租借记录");

        root.add(personcenter);
        root.add(powerBankType);
        root.add(powerBankRent);
        root.add(powerBankHistory);

        JTree tree=new JTree(root);
        jSplitPane.setLeftComponent(tree);

        Font font = new Font("宋体", Font.PLAIN, 18);
        UIManager.put("Label.font", font);

        jSplitPane.setRightComponent(new JLabel("欢迎进入充电宝租借商店"));

        tree.addTreeSelectionListener(new TreeSelectionListener() {
            @Override
            public void valueChanged(TreeSelectionEvent e) {
                Object obj=e.getNewLeadSelectionPath().getLastPathComponent();

                if (powerBankType.equals(obj)){
                    try {
                        jSplitPane.setRightComponent(new PowerBankTableUtil());
                        jSplitPane.setDividerLocation(150);
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    } catch (ClassNotFoundException ex) {
                        throw new RuntimeException(ex);
                    }

                }else if (powerBankRent.equals(obj)){
                    jSplitPane.setRightComponent(new PowerBankRent(currentUser));
                    jSplitPane.setDividerLocation(150);
                } else if (powerBankHistory.equals(obj)) {
                    try {
                        jSplitPane.setRightComponent(new HistoryGUI(currentUser));
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    } catch (ClassNotFoundException ex) {
                        throw new RuntimeException(ex);
                    }
                    jSplitPane.setDividerLocation(150);
                }else if (personcenter.equals(obj)){
                    try {
                        jSplitPane.setRightComponent(new Personal(currentUser));
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    } catch (ClassNotFoundException ex) {
                        throw new RuntimeException(ex);
                    }
                    jSplitPane.setDividerLocation(150);
                }
            }
        });

        setVisible(true);

    }

    public static void main(String[] args) {
        PowerBankManage powerBankManage =new PowerBankManage(null);
    }
}
