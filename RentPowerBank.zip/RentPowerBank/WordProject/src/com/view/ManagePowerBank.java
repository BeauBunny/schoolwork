package com.view;
import com.model.User;

import javax.swing.*;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.SQLException;

public class ManagePowerBank extends JFrame {


    ManagePowerBank(User currentUser) {
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setTitle("充电包租借界面");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JMenuBar jmb = new JMenuBar();

        JMenu setting = new JMenu("设置");
        JMenuItem aboutme = new JMenuItem("个人");
        JMenuItem exit = new JMenuItem("退出程序");
        setting.add(exit);
        setting.add(aboutme);
        jmb.add(setting);
        setJMenuBar(jmb);
        aboutme.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                try {
                    Personal personal = new Personal(currentUser);
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                }
                dispose();
            }
        });
        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                System.exit(0);//退出
            }
        });

        JSplitPane jSplitPane = new JSplitPane();
        jSplitPane.setContinuousLayout(true);//支持持续布局，即可以拉伸分界线
        jSplitPane.setDividerLocation(150);//分界线从左往右距离
        jSplitPane.setDividerSize(7);//分界线的宽度

        add(jSplitPane);
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("充电宝");
        DefaultMutableTreeNode powerBankListing = new DefaultMutableTreeNode("充电宝上架");
        DefaultMutableTreeNode powerBankDelisting = new DefaultMutableTreeNode("充电宝下架");
        DefaultMutableTreeNode powerBankInformation = new DefaultMutableTreeNode("修改充电宝信息");
        DefaultMutableTreeNode userInformation = new DefaultMutableTreeNode("修改用户信息");

        root.add(powerBankListing);
        root.add(powerBankDelisting);
        root.add(powerBankInformation);
        root.add(userInformation);

        JTree tree = new JTree(root);
        jSplitPane.setLeftComponent(tree);
        jSplitPane.setRightComponent(new JLabel("商店管理"));

        tree.addTreeSelectionListener(new TreeSelectionListener() {
            @Override
            public void valueChanged(TreeSelectionEvent e) {
                Object obj=e.getNewLeadSelectionPath().getLastPathComponent();

                if (powerBankListing.equals(obj)){
                    jSplitPane.setRightComponent(new ListingGui());
                    jSplitPane.setDividerLocation(150);
                }else if (powerBankDelisting.equals(obj)){
                    jSplitPane.setRightComponent(new DelistingGUI());
                    jSplitPane.setDividerLocation(150);
                } else if (powerBankInformation.equals(obj)) {
                    try {
                        jSplitPane.setRightComponent(new PowerBankChangeGUI());
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    } catch (ClassNotFoundException ex) {
                        throw new RuntimeException(ex);
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }
                    jSplitPane.setDividerLocation(150);
                }else if (userInformation.equals(obj)) {
                    try {
                        jSplitPane.setRightComponent(new ChangeUserGUI());
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    } catch (ClassNotFoundException ex) {
                        throw new RuntimeException(ex);
                    }
                    jSplitPane.setDividerLocation(150);
                }
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        ManagePowerBank m=new ManagePowerBank(null);
    }
}