package com.view;

import com.Util.DBHelper;
import com.Util.UserDeleteUtil;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class ChangeUserGUI extends Box{
    private JTable table;
    private Vector<String> titles;
    private Vector<Vector> tableDate;
    private TableModel tableModel;

    public ChangeUserGUI() throws SQLException, ClassNotFoundException {
        super(BoxLayout.Y_AXIS);//组件垂直布局

        Box vBox=Box.createVerticalBox();

        Box box1=Box.createHorizontalBox();

        Box box2=Box.createHorizontalBox();
        JLabel username=new JLabel("用户名:");
        JTextField txt_username=new JTextField(10);
        box2.add(Box.createHorizontalStrut(200));
        box2.add(username);
        box2.add(Box.createHorizontalStrut(5));
        box2.add(txt_username);
        box2.add(Box.createHorizontalStrut(200));

        Box box3=Box.createHorizontalBox();
        JButton delete=new JButton("删  除");
        box3.add(delete);


        String[] ts={"编号","用户名称","用户余额"};
        titles=new Vector<>();
        for (String title : ts) {
            titles.add(title);
        }

        tableDate=new Vector<>();


        tableModel=new DefaultTableModel(tableDate,titles);
        table=new JTable(tableModel);

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {//表格点击事件处理
            int row=table.getSelectedRow();
            txt_username.setText((String) table.getValueAt(row,1)+"");

            }
        });

        delete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String username=txt_username.getText().trim();

                try {
                    UserDeleteUtil.UserDelete(username);
                    JOptionPane.showMessageDialog(null,"删除成功!");
                    txt_username.setText("");
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        RequestDate();
        JScrollPane scrollPane=new JScrollPane(table);
        box1.add(scrollPane);

        vBox.add(box1);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(box2);
        vBox.add(Box.createVerticalStrut(5));
        vBox.add(box3);
        vBox.add(Box.createVerticalStrut(20));

        add(vBox);

    }
    public void RequestDate() throws SQLException, ClassNotFoundException {
        Connection con= DBHelper.getConn();
        String sql="select * from t_user";
        PreparedStatement pstmt=con.prepareStatement(sql);
        ResultSet rs=pstmt.executeQuery();
        while (rs.next()){
            Vector vector=new Vector();
            vector.add(rs.getInt("id"));
            vector.add(rs.getString("username"));
            vector.add(rs.getString("money"));

            tableDate.add(vector);
        }

    }


}
