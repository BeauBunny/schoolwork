package com.view;

import com.Util.PowerBankChargerCalculationUtil;
import com.Util.UserMoneyUtil;
import com.model.PowerBankType;
import com.model.TimeDate;
import com.model.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PowerBankRent extends Box {



//    private  String[] rentTime={"1小时/1.5元", "2小时/2.8元", "3小时/4元"};

    public PowerBankRent(User user){

        super(BoxLayout.Y_AXIS);
        Font font = new Font("宋体", Font.PLAIN, 18);
        UIManager.put("Button.font", font);
        UIManager.put("Label.font", font);
        UIManager.put("TextField.font", font);
        UIManager.put("ComboBox.font", font);
        UIManager.put("CheckBox.font", font);
        UIManager.put("RadioButton.font", font);

        JPanel jPanel=new JPanel();

        Box vbox=Box.createVerticalBox();

        Box txtBox=Box.createHorizontalBox();
        JLabel worn=new JLabel("提示：在你租借充电宝之前，请确认钱包是否超过4元!!!");
        worn.setFont(new Font("Dialog",Font.BOLD,20));
        txtBox.add(worn);

        Box typeBox=Box.createHorizontalBox();
        String[] powerBank={"普通充电宝","便携式充电宝","大电充电宝","实惠充电宝"};
        JLabel type=new JLabel("充电宝类型:");
        JComboBox comboBox=new JComboBox(new DefaultComboBoxModel(powerBank));
        typeBox.add(Box.createHorizontalStrut(50));
        typeBox.add(type);
        typeBox.add(Box.createHorizontalStrut(5));
        typeBox.add(comboBox);
        typeBox.add(Box.createHorizontalStrut(100));


        Box timeBox=Box.createHorizontalBox();
        JLabel time=new JLabel("租 借 时 间:");
        String[] rentTime={"1小时/1.5元", "2小时/2.8元", "3小时/4元"};
        JComboBox comboBox1=new JComboBox<>(new DefaultComboBoxModel<>(rentTime));
        timeBox.add(Box.createHorizontalStrut(50));
        timeBox.add(time);
        timeBox.add(Box.createHorizontalStrut(5));
        timeBox.add(comboBox1);
        timeBox.add(Box.createHorizontalStrut(100));

        comboBox.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    Object item = e.getItem();
                    DefaultComboBoxModel model = (DefaultComboBoxModel) comboBox1.getModel();
                    model.removeAllElements();
                    if (item.equals("便携式充电宝")) {
                        model.addElement("1小时/2元");
/*                        model.addElement("2小时/3.8元");
                        model.addElement("3小时/5.5元");*/
                    } else if (item.equals("大电充电宝")) {
                        model.addElement("1小时/2元");
//                        model.addElement("2小时/3.8元");
//                        model.addElement("3小时/5.5元");
                    } else if (item.equals("实惠充电宝")) {
                        model.addElement("1小时/1元");
//                        model.addElement("2小时/1.8元");
//                        model.addElement("3小时/2.5元");
                    }  else if (item.equals("普通充电宝")) {
                        model.addElement("1小时/1.5元");
//                        model.addElement("2小时/2.8元");
//                        model.addElement("3小时/4元");
                    }
                }
            }
        });

        Box btnBox=Box.createHorizontalBox();
        JButton rent=new JButton("租    借");
        JButton recharge=new JButton("充    值");
        btnBox.add(rent);
        btnBox.add(Box.createHorizontalStrut(80));
        btnBox.add(recharge);

        rent.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {


                try {
                    if(UserMoneyUtil.getUserMoney(user.getUsername())>=4.0){
                        Date date=new Date();
                        SimpleDateFormat dateFormat=new SimpleDateFormat("yyy-MM-dd HH:mm:ss");
                        String time=dateFormat.format(date);
                        TimeDate.setStarttime(time);
                        UserMoneyUtil.usermoney-=2.0;

                        if (TimeDate.hours>=1){
                            UserMoneyUtil.usermoney-=2;
                        }else if (TimeDate.hours>=2){
                            UserMoneyUtil.usermoney-=4;
                        }else if (TimeDate.hours>=3){
                            UserMoneyUtil.usermoney-=6;
                        }
                        try {
                            UserMoneyUtil.consumelaterMoney(UserMoneyUtil.usermoney,Personal.username);
                        } catch (ClassNotFoundException e) {
                            throw new RuntimeException(e);
                        } catch (SQLException e) {
                            throw new RuntimeException(e);
                        }
                    }else {
                        JOptionPane.showMessageDialog(null,"你的钱包不足1.5元！");
                    }
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }

                //点击租借按钮后获取时间

//                System.out.println(time);

                String text=(String)comboBox.getSelectedItem();

                PowerBankType p=new PowerBankType(text);
                PowerBankType.setPowerBankType(text);
                try {
                    PowerBankChargerCalculationUtil.commonPowerBank(p,user);
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        recharge.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                Recharge r=new Recharge();
            }
        });

        vbox.add(Box.createVerticalStrut(50));
        vbox.add(txtBox);
        vbox.add(Box.createVerticalStrut(50));
        vbox.add(typeBox);
        vbox.add(Box.createVerticalStrut(50));
        vbox.add(timeBox);
        vbox.add(Box.createVerticalStrut(50));
        vbox.add(btnBox);
        vbox.add(Box.createVerticalStrut(50));

        add(vbox);

    }


}
