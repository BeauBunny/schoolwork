package com.view;

import java.io.IOException;

public class Test {
    public static void main(String[] args) throws IOException {
        GUI gui=new GUI();
//        RegisterFrm registerFrm=new RegisterFrm();
    }
}
