package com.view;

import com.DAO.RegisterDao;
import com.Util.DBHelper;
import com.model.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Random;

public class RegisterFrm extends JFrame {
    private JLabel yourName;
    private JLabel birthday;
    private JLabel sex;
    private  JLabel homeLocation;
    private JLabel phoneTouch;
    private JLabel password;
    private JLabel confirmPassword;
    private JTextField txt_name;
    private JTextField txt_birthday;
    private JRadioButton man;
    private JRadioButton woman;
    private  JTextField txt_location;
    private JTextField txt_phoneTouch;
    private JPasswordField txt_password;
    private JPasswordField txt_confirmPassword;
    private JButton register;
    private JButton backToLogin;




    RegisterFrm() throws IOException {
        setSize(500,330);
        setTitle("注册界面");
        setLocationRelativeTo(null);
        setResizable(false);

//        BackgroundPanel backgroundPanel=new BackgroundPanel(ImageIO.read(new File("C:\\Users\\machenlke\\IdeaProjects\\WordProject\\image\\Background.jpg")));

        Box vBox=Box.createVerticalBox();

        Box nameBox=Box.createHorizontalBox();
        yourName=new JLabel("用户名:");
        txt_name=new JTextField(15);
        nameBox.add(Box.createHorizontalStrut(50));
        nameBox.add(yourName);
        nameBox.add(Box.createHorizontalStrut(13));
        nameBox.add(Box.createHorizontalStrut(20));
        nameBox.add(txt_name);
        nameBox.add(Box.createHorizontalStrut(70));


        Box passwordBox=Box.createHorizontalBox();
        password=new JLabel("密    码:");
        txt_password=new JPasswordField(15);
        passwordBox.add(Box.createHorizontalStrut(50));
        passwordBox.add(password);
        passwordBox.add(Box.createHorizontalStrut(13));
        passwordBox.add(Box.createHorizontalStrut(20));
        passwordBox.add(txt_password);
        passwordBox.add(Box.createHorizontalStrut(70));

        Box confirmPasswordBox=Box.createHorizontalBox();
        confirmPassword=new JLabel("确认密码:");
        txt_confirmPassword=new JPasswordField(15);
        confirmPasswordBox.add(Box.createHorizontalStrut(50));
        confirmPasswordBox.add(confirmPassword);
        confirmPasswordBox.add(Box.createHorizontalStrut(20));
        confirmPasswordBox.add(txt_confirmPassword);
        confirmPasswordBox.add(Box.createHorizontalStrut(70));

        Box genderBox=Box.createHorizontalBox();
        JLabel gLabel=new JLabel("性    别:");
        ButtonGroup sex=new ButtonGroup();
        man=new JRadioButton("男");
        woman=new JRadioButton("女");
        sex.add(man);
        sex.add(woman);
        man.setSelected(true);
        genderBox.add(gLabel);
        genderBox.add(Box.createHorizontalStrut(30));
        genderBox.add(man);
        genderBox.add(Box.createHorizontalStrut(30));
        genderBox.add(woman);

        Box cBox=Box.createHorizontalBox();
        JLabel cLabel=new JLabel("验证码:");
        JTextField cField=new JTextField(4);
        JLabel cImg=new JLabel(new ImageIcon());
        cImg.setToolTipText("点击刷新");

        Box registerBox=Box.createHorizontalBox();
        register=new JButton("注   册");
        backToLogin=new JButton("返   回");
        registerBox.add(Box.createHorizontalStrut(50));
        registerBox.add(register);
        registerBox.add(Box.createHorizontalStrut(20));
        registerBox.add(backToLogin);
        registerBox.add(Box.createHorizontalStrut(50));


        vBox.add(Box.createVerticalStrut(40));
        vBox.add(nameBox);
        vBox.add(Box.createVerticalStrut(45));
        vBox.add(passwordBox);
        vBox.add(Box.createVerticalStrut(45));
        vBox.add(confirmPasswordBox);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(genderBox);
        vBox.add(Box.createVerticalStrut(20));
        vBox.add(registerBox);

//        backgroundPanel.add(vBox);
        this.add(vBox);

        register.addActionListener(new ActionListener() {
         @Override
             public void actionPerformed(ActionEvent e) {
                 confirmPasswordUtil(e);
            }
        });
        backToLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Object object=e.getSource();
                if (object==backToLogin){
                    try {
                        GUI gui=new GUI();
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }
                }
                dispose();
            }
        });


        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }




    public JLabel getBirthday() {
        return birthday;
    }

    public void setBirthday(JLabel birthday) {
        this.birthday = birthday;
    }

    public JLabel getSex() {
        return sex;
    }

    public void setSex(JLabel sex) {
        this.sex = sex;
    }

    public JLabel getYourName() {
        return yourName;
    }

    public void setYourName(JLabel yourName) {
        this.yourName = yourName;
    }

    public JLabel getHomeLocation() {
        return homeLocation;
    }

    public void setHomeLocation(JLabel homeLocation) {
        this.homeLocation = homeLocation;
    }



    public JLabel getPhoneTouch() {
        return phoneTouch;
    }

    public void setPhoneTouch(JLabel phoneTouch) {
        this.phoneTouch = phoneTouch;
    }

    public JTextField getTxt_name() {
        return txt_name;
    }

    public void setTxt_name(JTextField txt_name) {
        this.txt_name = txt_name;
    }

    public JTextField getTxt_birthday() {
        return txt_birthday;
    }

    public void setTxt_birthday(JTextField txt_birthday) {
        this.txt_birthday = txt_birthday;
    }


    public JLabel getPassword() {
        return password;
    }

    public void setPassword(JLabel password) {
        this.password = password;
    }

    public JLabel getConfirmPassword() {
        return confirmPassword;
    }

    public void setConfirmPassword(JLabel confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    public JRadioButton getMan() {
        return man;
    }

    public void setMan(JRadioButton man) {
        this.man = man;
    }

    public JRadioButton getWoman() {
        return woman;
    }

    public void setWoman(JRadioButton woman) {
        this.woman = woman;
    }

    public JPasswordField getTxt_password() {
        return txt_password;
    }

    public void setTxt_password(JPasswordField txt_password) {
        this.txt_password = txt_password;
    }

    public JPasswordField getTxt_confirmPassword() {
        return txt_confirmPassword;
    }

    public void setTxt_confirmPassword(JPasswordField txt_confirmPassword) {
        this.txt_confirmPassword = txt_confirmPassword;
    }

    public JTextField getTxt_location() {
        return txt_location;
    }

    public void setTxt_location(JTextField txt_location) {
        this.txt_location = txt_location;
    }

    public JTextField getTxt_phoneTouch() {
        return txt_phoneTouch;
    }

    public void setTxt_phoneTouch(JTextField txt_phoneTouch) {
        this.txt_phoneTouch = txt_phoneTouch;
    }

    public void confirmPasswordUtil(ActionEvent e){
        String username=txt_name.getText().trim();
        String password=new String(txt_password.getPassword()).trim();
//        JRadioButton selectButton=(JRadioButton)e.getSource();
//        String gender=selectButton.getText();
        String confirmPassword=new String(txt_confirmPassword.getPassword());
        int num = (int) (Math.random() * 100);

        if ("".equals(username) || "".equals(password)){
            JOptionPane.showMessageDialog(null,"用户名或密码不能为空！");
            txt_password.setText("");
            txt_confirmPassword.setText("");
            txt_password.requestFocus();

        }else if (password.equals(confirmPassword)){
            System.out.println("密码一致");
            User user=new User(num,username,password);
            Connection con=null;

            try {
                con= DBHelper.getConn();
            } catch (ClassNotFoundException ex) {
                throw new RuntimeException(ex);
            }

            try {
                if (RegisterDao.register(con,user)==true){
                    JOptionPane.showMessageDialog(null,"注册成功，请点击返回按钮");
                }
            } catch (SQLException ex) {
                    throw new RuntimeException(ex);
            }

        }else {
            JOptionPane.showMessageDialog(null,"密码不一致,请重新输入!");
            txt_password.setText("");
            txt_confirmPassword.setText("");
            txt_password.requestFocus();

        }




    }
}
